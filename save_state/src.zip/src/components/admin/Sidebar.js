import React from 'react'
import { Link } from 'react-router-dom'

const Sidebar = () => {

    return (
        <div className="sidebar-wrapper" >
            <nav id="sidebar">
                <ul className="list-unstyled components">
                    <li>
                        <Link to="/dashboard"><i className="fa fa-tachometer"></i> Dashboard</Link>
                    </li>

                    <li>
                        <Link to="/admin/actors"><i className="fa fa-clipboard"></i> Actors</Link>
                    </li>

                    <li>
                        <Link to="/admin/producers"><i className="fa fa-user-o"></i> Producers</Link>
                    </li>

                    <li>
                        <Link to="/admin/movies"><i className="fa fa-film"></i> Movies</Link>
                    </li>

                </ul>
            </nav>
        </div>
    )
}

export default Sidebar
